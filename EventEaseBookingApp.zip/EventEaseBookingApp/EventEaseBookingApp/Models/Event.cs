﻿using System;

namespace EventEaseBookingSystem.Models
{
    public class Event
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string ImageUrl { get; set; } // Placeholder image URL

        // Foreign key for Venue
        public int VenueId { get; set; }
        public Venue Venue { get; set; }

        // Navigation property: one Event can have many Bookings
        public ICollection<Booking> Bookings { get; set; }
    }
}
