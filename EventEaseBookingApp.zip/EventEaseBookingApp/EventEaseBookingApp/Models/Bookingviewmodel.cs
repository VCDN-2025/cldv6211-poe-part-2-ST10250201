﻿using EventEaseBookingSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace EventEaseBookingApp.Models
{
    public class Bookingviewmodel
    {
        public class ApplicationDbContext : DbContext
        {
            public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
                : base(options)
            {
            }

            public DbSet<Venue> Venues { get; set; }
            public DbSet<Event> Events { get; set; }
            public DbSet<Booking> Bookings { get; set; }

            // Add DbSet for the View (no insert, update, or delete)
            public DbSet<BookingViewModel> BookingDetails { get; set; }
        }

    }
}
