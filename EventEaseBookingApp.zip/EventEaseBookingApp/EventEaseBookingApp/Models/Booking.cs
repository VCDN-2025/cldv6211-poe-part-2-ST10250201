﻿namespace EventEaseBookingSystem.Models
{
    public class Booking
    {
        public int Id { get; set; }

        // Foreign key for Event
        public int EventId { get; set; }
        public Event Event { get; set; }

        // Unique booking reference
        public string BookingReference { get; set; }
    }
}
