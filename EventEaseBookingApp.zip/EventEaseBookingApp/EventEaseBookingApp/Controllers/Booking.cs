﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventEaseBookingApp.Controllers
{
    public class Booking : Controller
    {
        public IActionResult Index()
        {
            return View();
            public async Task<IActionResult> Create(Booking booking)
        {
            if (ModelState.IsValid)
            {
                var existingBooking = await _context.Bookings
                    .AnyAsync(b => b.Event.VenueId == booking.Event.VenueId
                                    && booking.Event.StartDate < b.Event.EndDate
                                    && booking.Event.EndDate > b.Event.StartDate);

                if (existingBooking)
                {
                    ModelState.AddModelError("", "This venue is already booked for the selected time.");
                    return View(booking);
                }

                _context.Add(booking);
                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(booking);
        }

    }
    public class BookingController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BookingController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string searchTerm)
        {
            // Retrieve data from the view in the database
            var bookings = _context.BookingDetails.AsQueryable();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                bookings = bookings.Where(b => b.BookingReference.Contains(searchTerm) || b.EventName.Contains(searchTerm));
            }

            return View(await bookings.ToListAsync());
        }
    }

}

